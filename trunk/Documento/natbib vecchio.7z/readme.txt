Replacement natbib.sty, 11/3/2007.
----------------------------------

Some people have experienced problems with errors reported using MikTex, under WinXP, of type:

 !Package natbib Error: Bibliography not compatible with author-year citations.
 Press <return> to continue in numerical citation style.
 See the natbib package documentation for explanation.
 Type <H> for immidiate help
 ...

This occured with the latest version of natbib ~ 2009, when used with scientific ieee.bst or utphys.bst types of bibliographies.

Extract and place in Program Files/Miktex/tex/latex/natbib/
For Windows7 users: c:\Users\UserName\AppData\Roaming\MiKTeX\2.8\tex\latex\natbib\

overwriting the newer malfunctioning version.


/Regards,

Blake Redfield